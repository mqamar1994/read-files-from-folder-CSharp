﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo d = new DirectoryInfo(@"C:\Users\Muhammad Qamaruddin\Desktop\Muzzammil\Tutorials\C#");
            FileInfo[] Files = d.GetFiles("*.txt"); //Getting Text files
            List<string> fileNamesList = new List<string>();
            string[] str = new string[10];
            foreach (FileInfo file in Files)
            {
                string str1 = file.Name.Substring(0, file.Name.Length - 4);
                string str2 = str1.Substring(str1.IndexOf("Copy"));
                fileNamesList.Add(str2);
            }
            string[] fileNamesArray = new string[10];
            fileNamesArray = fileNamesList.ToArray();
            File.WriteAllLines(@"C:\Users\Muhammad Qamaruddin\Desktop\Muzzammil\Tutorials\Output.txt", fileNamesArray);
            fileNamesList.ForEach(Console.WriteLine);
            Console.ReadLine();
        }
    }
}
